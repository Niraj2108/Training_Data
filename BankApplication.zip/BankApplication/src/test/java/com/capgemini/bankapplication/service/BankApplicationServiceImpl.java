package com.capgemini.bankapplication.service;

import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.capgemini.bankapplication.ba.util.BAUtil;
import com.capgemini.bankapplication.beans.Customer;
import com.capgemini.bankapplication.beans.Transaction;
import com.capgemini.bankapplication.dao.BankApplicationDAO;
import com.capgemini.bankapplication.dao.BankApplicationDAOImpl;
import com.capgemini.bankapplication.exception.BAException;

public class BankApplicationServiceImpl implements BankApplicationService {
BankApplicationDAO dao = new BankApplicationDAOImpl();
	@Override
	public int createAccount(Customer customer) throws BAException {
		// TODO Auto-generated method stub
		return dao.createAccount(customer);
	}

	@Override
	public boolean deposit(int accountNo, double amountToDeposit) throws BAException {
		// TODO Auto-generated method stub
		 boolean status=dao.deposit(accountNo, amountToDeposit);
		 if(status)
				return status;
			else {
				throw new BAException("accountNo doesn't exists");
			}
		
	}

	@Override
	public boolean withdraw(int accountNo, double amountToWithdraw) throws BAException {
		// TODO Auto-generated method stub
		boolean status=dao.withdraw(accountNo, amountToWithdraw);
		 if(status)
				return status;
			else {
				throw new BAException("accountNo doesn't exists");
			}
	}

	@Override
	public Customer printCustomers(int accountNo) throws BAException {
		boolean status=dao.printCustomers(accountNo)!= null;
		if(status)
			return dao.printCustomers(accountNo);
		else {
			throw new BAException("accountNo doesn't exists");
		}
		// TODO Auto-generated method stub
		
	}


	@Override
	public int fundTransfer(Transaction transaction, int accountNo, int destinationAccNo,double amount) throws BAException {
		return dao.fundTransfer(transaction, accountNo, destinationAccNo, amount);
	}

	@Override
	public Transaction printTransactions(int accountNo) throws BAException {
		// TODO Auto-generated method stub
		boolean status=dao.printTransactions(accountNo)!= null;
		if(status)
			return dao.printTransactions(accountNo);
		else {
			throw new BAException("accountNo doesn't exists");
		}
		
	}

	@Override
	public boolean validateName(String name) throws BAException {
		// TODO Auto-generated method stub
		Pattern nameptn = Pattern.compile("^[A-Z]{1}[a-z]{4,}$");
		Matcher match = nameptn.matcher(name);
		if(match.matches()) {
			return true;
		}
		return false;
		
	}

	@Override
	public void validateId(int id) throws BAException {
		// TODO Auto-generated method stub
		String idRegEx = "[0-9]{3}";
		if (!Pattern.matches(idRegEx, String.valueOf(id))) {
			throw new BAException("id should be 3 digit number \n");
		}
		
	}

	@Override
	public boolean validateAccount(int accountNo) throws BAException {
		// TODO Auto-generated method stub
		boolean resultFlag = false;
		String idRegEx = "[0-9]{7}";
		if (!Pattern.matches(idRegEx, String.valueOf(accountNo))) {
			throw new BAException("id should be 7 digit number \n");
		} else {
			resultFlag = true;
		}
		return resultFlag;
		}
	

	@Override
	public boolean isValid(String email) throws BAException {
		// TODO Auto-generated method stub
		boolean resultFlag = false;
		 String regex = "^[\\w-_\\.+]*[\\w-_\\.]\\@([\\w]+\\.)+[\\w]+[\\w]$";

		if (!Pattern.matches(regex,email)) {
			throw new BAException("email should be in 'abc2xyz.com' format\n");
		} else {
			resultFlag = true;
		}
		return resultFlag;
		 
	}

	@Override
	public boolean validateMobile(long mobileNo) throws BAException {
		// TODO Auto-generated method stub 
		boolean resultFlag = false;
		String idRegEx = "^[7-9][0-9]{9}$";
		if (!Pattern.matches(idRegEx, String.valueOf(mobileNo))) {
			throw new BAException("id should be 10 digit number and start with 7,8 or 9 \n");
		} else {
			resultFlag = true;
		}
		return resultFlag;
		 
		
		
	}

	@Override
	public boolean validateBalance(double balance) throws BAException {
		// TODO Auto-generated method stub
		boolean resultFlag = false;
		if (balance <= 0) {
			throw new BAException("balance should not be 0 or less than 0 \n");
		} else {
			resultFlag = true;
		}
		return resultFlag;
		}

	@Override
	public Map<Integer, Customer> getAllCustomers() throws BAException {
		// TODO Auto-generated method stub
		return dao.getAllCustomers();
	}

	@Override
	public Map<Integer, Transaction> getAllTransactions() throws BAException {
		// TODO Auto-generated method stub
		return dao.getAllTransactions();
	}

	@Override
	public boolean validateAccountNo(int accountNo) throws BAException {
		// TODO Auto-generated method stub
		boolean flag = false;
		Customer customer = BAUtil.mapCustomer.get(accountNo);
		if(customer!= null) {
			flag = true;
		}
		else {
			flag= false;
			throw new BAException("Entered accountNo is invalid");
		}
		return flag;
	}

	@Override
	public boolean validateWithdraw(int accountNo, double amount) throws BAException {
		// TODO Auto-generated method stub
		boolean flag=false;
		Transaction transaction=BAUtil.map1.get(accountNo);
		if(transaction!=null) {
			if(transaction.getBalance()>amount) {
				flag=true;
			}
		}else {
			flag=false;
			throw new BAException("Entered accountNo is invalid");
		}
		return flag;
	}

	}


