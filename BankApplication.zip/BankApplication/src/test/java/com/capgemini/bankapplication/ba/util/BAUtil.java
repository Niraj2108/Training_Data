package com.capgemini.bankapplication.ba.util;

import java.util.HashMap;
import java.util.Map;

import com.capgemini.bankapplication.beans.Customer;
import com.capgemini.bankapplication.beans.Transaction;

public class BAUtil {
	public static Map<Integer,Customer> mapCustomer = new HashMap<>();

	static {

		mapCustomer.put(111,new Customer(111,"Sam", "Manchester", "s.a@gmail.com",987654321L, 45000d));
		mapCustomer.put(222,new Customer(222,"Mark", "Birmingham", "m.a@gmail.com",987654389L, 785000d));
		mapCustomer.put(333,new Customer(333,"Tom", "Southampton", "t.o@gmail.com",987653421L, 574500d));
		mapCustomer.put(444,new Customer(444,"Lee", "Manchester", "l.e@gmail.com",987654881L, 674500d));
		mapCustomer.put(555,new Customer(555,"Charles", "Birmingham", "c.h2gmail.com",983354321L, 43500d));
	}

	public static Map<Integer, Customer> getList() {
		return mapCustomer;
	}

	public static void setList( Map<Integer, Customer> map) {
		BAUtil.mapCustomer = mapCustomer;
	}
	public static Map<Integer,Transaction> map1 = new HashMap<>();

	static {

		map1.put(111,new Transaction(112,"credit", "22/05/12",111 ,444,1000d, 45000d));
		map1.put(222,new Transaction(232,"credit", "22/06/12",222,333,2500d, 785000d));
		map1.put(333,new Transaction(533,"debit", "25/06/12",333,555,1500d, 574500d));
		map1.put(444,new Transaction(944,"credit", "12/07/12",444,111,1000d, 674500));
		map1.put(555,new Transaction(655,"debit", "02/08/12",555,222,5000d,43500));
	}

	public static Map<Integer, Transaction> getList1() {
		return map1;
	}

	public static void setList1( Map<Integer, Customer> map) {
		BAUtil.map1 = map1;
	}
	

}
