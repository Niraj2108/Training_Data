package com.capgemini.bankapplication.dao;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

import com.capgemini.bankapplication.ba.util.BAUtil;
import com.capgemini.bankapplication.beans.Customer;
import com.capgemini.bankapplication.beans.Transaction;
import com.capgemini.bankapplication.exception.BAException;

public class BankApplicationDAOImpl implements BankApplicationDAO {
    boolean status=false;
	public int createAccount(Customer customer) {
		// TODO Auto-generated method stub
		int id = (int) (Math.random() * 1000);
		customer.setAccountNo(id);

		Map<Integer, Customer> customers = BAUtil.getList();
		customers.put(id,customer );
		
		return id;
	}

	@Override
	public boolean deposit(int accountNo, double amountToDeposit) {
		double NewBalance=0;
		boolean status=false;
		Customer customer= BAUtil.mapCustomer.get(accountNo);
		Transaction transaction= BAUtil.map1.get(accountNo);
		if(customer!=null)
		{
		status=true;
			NewBalance=customer.getBalance()+amountToDeposit;
		customer.setBalance(NewBalance);
		NewBalance=transaction.getBalance()+amountToDeposit;
		transaction.setBalance(NewBalance);
		transaction.setTransactionType("credit");
		Date transDate = new Date();
		DateFormat df2= new SimpleDateFormat("dd/MM/yy");
        java.util.Date date= new java.util.Date();
        String transDate1= " ";
        transDate1= df2.format(date);
        transaction.setTransactionDate(transDate1);
        transaction.setDestinationAccNo(accountNo);
        transaction.setAmount(amountToDeposit);
		}
		return status;
	}

	@Override
	public boolean withdraw(int accountNo, double amountToWithdraw) {
		// TODO Auto-generated method stub
		double NewBalance=0;
		boolean status=false;
		Customer customer= BAUtil.mapCustomer.get(accountNo);
		Transaction transaction= BAUtil.map1.get(accountNo);
		if(customer!=null)
			status=true;
			NewBalance=customer.getBalance()-amountToWithdraw;
		customer.setBalance(NewBalance);
		NewBalance=transaction.getBalance()-amountToWithdraw;
		transaction.setBalance(NewBalance);
		transaction.setTransactionType("debit");
		Date transDate = new Date();
		DateFormat df2= new SimpleDateFormat("dd/MM/yy");
        java.util.Date date= new java.util.Date();
        String transDate1= " ";
        transDate1= df2.format(date);
        transaction.setTransactionDate(transDate1);
        transaction.setDestinationAccNo(accountNo);
        transaction.setAmount(amountToWithdraw);
		return status;
	}

	@Override
	public Customer printCustomers(int accountNo) {
		// TODO Auto-generated method stub
		Customer customer= BAUtil.mapCustomer.get(accountNo);
		
		if(customer != null) 
			status=true;
			//
		return customer;
		
	}

	

	@Override
	public int fundTransfer(Transaction transaction, int accountNo, int destinationAccNo, double amount) throws BAException {
		int transId= 0;
		double balanceSourceAcc = 0.0;
		double balanceDestinationAcc = 0.0;
		Transaction customer1= BAUtil.map1.get(accountNo);
		Transaction customer2= BAUtil.map1.get(destinationAccNo);
		Set keys= BAUtil.map1.keySet();
		Iterator iterator =keys.iterator();
		while(iterator.hasNext()){
			int key = (int) iterator.next();
			if( key == accountNo) /*{
				balanceSourceAcc =customer1.getBalance()- transaction.getBalance();
				if(balanceSourceAcc<customer1.getBalance()) {
					transaction.setTransactionType("Debit");
				}
				else
					transaction.setTransactionType("Credit");
				customer1.setBalance(balanceSourceAcc);
				balanceDestinationAcc =customer1.getBalance()+transaction.getBalance();
				customer2.setBalance(balanceDestinationAcc);
				break;
				
			}*/
			{
				balanceSourceAcc=customer1.getBalance()-amount;
				{
				customer1.setBalance(balanceSourceAcc);
				}
				customer1.setTransactionType("debit");
			
				balanceDestinationAcc=customer2.getBalance()+amount;
				customer2.setTransactionType("credit");
				customer2.setBalance(balanceDestinationAcc);
				
			}
			
		}
		
		transId = (int) (Math.random()*1000);
		Date transDate = new Date();
		DateFormat df2= new SimpleDateFormat("dd/MM/yy");
        java.util.Date date= new java.util.Date();
        String transDate1= " ";
        transDate1= df2.format(date);
        transaction.setTransactionDate(transDate1);
		transaction.setTransactionId(transId);
		BAUtil.map1.put(accountNo, transaction);
		return transId;
	}
	

	@Override
	public Transaction printTransactions(int accountNo) {
		// TODO Auto-generated method stub
Transaction transaction= BAUtil.map1.get(accountNo);
		
		if( transaction!= null) 
			status=true;
			//
		return transaction;
	}

	@Override
	public Map<Integer, Customer> getAllCustomers() throws BAException {
		// TODO Auto-generated method stub
		return BAUtil.getList();
	}

	@Override
	public Map<Integer, Transaction> getAllTransactions() throws BAException {
		// TODO Auto-generated method stub
		return BAUtil.getList1();
	}
	

}