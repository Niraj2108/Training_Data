package com.capgemini.bankapplication.exception;

public class BAException extends Exception {
	public BAException(String message) {
		super(message);
	}

}
