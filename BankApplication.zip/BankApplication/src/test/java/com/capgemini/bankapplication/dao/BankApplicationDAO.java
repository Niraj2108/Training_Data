package com.capgemini.bankapplication.dao;

import java.util.List;
import java.util.Map;

import com.capgemini.bankapplication.beans.Customer;
import com.capgemini.bankapplication.beans.Transaction;
import com.capgemini.bankapplication.exception.BAException;

public interface BankApplicationDAO {
	public int createAccount(Customer customer) throws BAException;
	public boolean deposit(int accountNo,double amountToDeposit) throws BAException;
	public boolean withdraw(int accountNo, double amountToWithdraw) throws BAException;
	public Customer printCustomers(int accountNo) throws BAException;
	public int fundTransfer(Transaction transaction,int accountNo, int destinationAccNo,double amount) throws BAException;
	public Transaction printTransactions(int accountNo) throws BAException;
	public Map<Integer, Customer> getAllCustomers() throws BAException;
	public Map<Integer, Transaction> getAllTransactions() throws BAException;

}
