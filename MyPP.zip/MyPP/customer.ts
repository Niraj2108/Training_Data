export class Customer {
  accountNo: number;
    name: string;
    mobileNo: number;
    balance: number;
}
