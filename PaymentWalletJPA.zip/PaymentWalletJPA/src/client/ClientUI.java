package client;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import java.util.Scanner;

import bean.Bank;
import bean.Customer;
import service.BankService;

public class ClientUI {

	static Scanner sc = new Scanner(System.in);
	Customer cust = new Customer();
	Bank bank = new Bank();
	BankService bser = new BankService();

	static List<String> transactionList = new ArrayList<String>();

	static int accountNo = 87711000;
	static int custId = 100;

	public void createAccount() {
		Bank bank = new Bank();
		Customer cust = new Customer();
		System.out.println("Enter the Customer name");
		String name = sc.next();
		System.out.println("Enter the Mobile Number");
		long mob = sc.nextLong();
		System.out.println("Enter the email Id");
		String email = sc.next();
		System.out.println("Enter the Accout_Type");
		String accType = sc.next();
		cust.setName(name);
		cust.setPhoneNo(mob);
		cust.setEmailId(email);
		cust.setAccType(accType);

		cust.setAccount(bank);
		bser.create(cust);
		System.out.println("Account is Created Successfully for Account No: " + bank.getAccountNo());
	}

	public void showBalance() {

		System.out.println("Enter Account No");
		int accountNo = sc.nextInt();
		bank = bser.showBalance(accountNo);

		System.out.println("Account No : " + bank.getAccountNo());
		System.out.println("Balance : " + bank.getBalance());

	}

	public void deposit() {
		System.out.println("Enter the Account No");
		int accountNo = sc.nextInt();
		System.out.println("Enter the Amount you Want to Add");
		double balance = sc.nextDouble();
		bser.deposit(accountNo, balance);
		System.out.println("Amount Deposited Successfully");
		transactionList.add("Rupees " + balance + " deposited in Account " + accountNo);

	}

	public void withdraw() {
		System.out.println("Enter the Account No");
		int accountNo = sc.nextInt();
		System.out.println("Enter the Amount you Want to Withdraw");
		double balance = sc.nextDouble();
		bser.withdraw(accountNo, balance);
		System.out.println("Amount Withdrawl Successfully");
		transactionList.add("Rupees " + balance + " Withdrawl from Account " + accountNo);
	}

	public void fundTransfer() {
		System.out.println("Enter the account number from which you have to transfer money");
		int accountNo1 = sc.nextInt();
		System.out.println("Enter the account number to which you have to transfer money");
		int accountNo2 = sc.nextInt();
		System.out.println("Enter the Amount to be Transfer");
		double balance = sc.nextDouble();
		bser.fundTransfer(accountNo1, accountNo2, balance);
		System.out.println("Amount Transferred Successfully");
		transactionList.add("Rupees " + balance + " Transferred from Account No: " + accountNo1 + " to Account No: " + accountNo2);
	}

	public void printTransaction() {
		for (String result : transactionList) {
			System.out.println(result);
		}
	}
}
