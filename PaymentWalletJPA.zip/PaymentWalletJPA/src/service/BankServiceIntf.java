package service;

public interface BankServiceIntf {

}
