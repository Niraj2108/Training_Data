package ui;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import bean.BankDetails;
import bean.CustomerDetails;

import service.BankService;

public class Ui {
	static Scanner sc = new Scanner(System.in);

	static List<String> transactionList = new ArrayList<String>();
	
	// Fund Transfer Method from one Account to Another.
	public void fundTransfer() {
		// TODO Auto-generated method stub
		System.out.println("Enter the account number from which you have to transfer money");
		int accNo1 = sc.nextInt();
		System.out.println("Enter the account number to which you have to transfer money");
		int accNo2 = sc.nextInt();
		System.out.println("Enter the Amount to be Transfer");
		double balance = sc.nextDouble();
		BankService bser = new BankService();
		BankDetails b1 = new BankDetails();
		BankDetails b2 = new BankDetails();
		bser.tranferAmount(accNo1, accNo2, balance);

		transactionList.add("Rupees " + balance + " Transferred from " + accNo1 + " to Account " + accNo2);
	}

	public void printTransaction() {
		// TODO Auto-generated method stub
		for (String result : transactionList) {
			System.out.println(result);
		}

	}

	public void deposit() {
		// TODO Auto-generated method stub
		BankDetails b = new BankDetails();
		BankService bser = new BankService();
		System.out.println("Enter Account No:");
		int accNo = sc.nextInt();
		System.out.println("Enter the Amount to be added");
		double balance = sc.nextDouble();
		// b=bser.getDetails(accNo);
		bser.addBalance(accNo, balance);
		System.out.println("Amount deposited Successfully");
		transactionList.add("Rupees " + balance + " deposited in Account " + accNo);
	}

	public void withdraw() {
		BankDetails b = new BankDetails();
		BankService bser = new BankService();
		System.out.println("Enter Account No:");
		int accNo = sc.nextInt();
		System.out.println("Enter the Amount to be Withdraw");
		double balance = sc.nextDouble();
		// b=bser.getDetails(accNo); 11 sept
		bser.deductBalance(accNo, balance);
		transactionList.add("Rupees " + balance + " Withdrawl from Account " + accNo);
	}

	// It will show the balance in your Account
	public void showBalance() {
		// TODO Auto-generated method stub
		BankDetails b = new BankDetails();
		System.out.println("Enter the account no:");
		int accNo = sc.nextInt();
		BankService bser = new BankService();
		double balance = b.getBalance();
		System.out.println(bser.getDetails(accNo));

	}

	// This method eill help you to open account in a bank.
	public void createAccount() {
		// TODO Auto-generated method stub
		System.out.println("Enter the Customer name");
		String name = sc.next();
		System.out.println("Enter the Mobile Number");
		long mob = sc.nextLong();
		System.out.println("Enter the email Id");
		String email = sc.next();
		System.out.println("Enter the Accout_Type");
		String accType = sc.next();
		CustomerDetails c = new CustomerDetails(name, mob, email, accType);
		BankDetails b = new BankDetails(c);
		BankService bser = new BankService();
		bser.storeDetails(b);
		System.out.println("Acoount has been created successfully" + "\n And the Account no is : " + b.getAccNo());

	}
}
