package com.capg.exception;

public class InvalidException extends Exception{
	
	public InvalidException(String s){
		System.out.println(s);
		
	}
	

}
