package com.capgemini.bankingproject.exception;

public class BankJpaException extends Exception{

	public BankJpaException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

}
